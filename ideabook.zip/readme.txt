This disk contains program listings from The Microcontroller Idea 
Book by Jan Axelson. The file names are coded to the listing 
numbers in the book.

Examples:   Program listing in book:      Filename on disk:
            4-1                           L4-1.BAS
            9-3                           L9-3.BAS
            B-2 (appendix B)              LB-2.BAS

All BASIC-52 programs have the extension .BAS.
Chapter 13 also has assembly-language source files (extension .ASM), 
a listing file (.LST), and an Intel Hex file (.IHX).

The Microcontroller Idea Book is published by

Lakeview Research
2209 Winnebago St.
Madison, WI  53704
Phone: 608-241-5824
Fax: 608-241-5848
Email: jaxelson@lvr.com
WWW: http://www.lvr.com


                                                                                                                                                                                                                                                               "���
